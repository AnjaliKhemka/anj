/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tcs.ignite.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author 1041737
 */
public class ConnectionManager {
    Connection cn;
    
    public Connection getSQLConnection() throws ClassNotFoundException, SQLException{
        String dbPath = "jdbc:mysql://localhost:3306/jdbc_demo";
        String username = "root";
        String password = "root";
        Class.forName("com.mysql.jdbc.Driver");
        
        cn = DriverManager.getConnection(dbPath, username, password);
        return cn;
    }
    
    public void closeConnection() throws SQLException{
        cn.close();
    }
}
